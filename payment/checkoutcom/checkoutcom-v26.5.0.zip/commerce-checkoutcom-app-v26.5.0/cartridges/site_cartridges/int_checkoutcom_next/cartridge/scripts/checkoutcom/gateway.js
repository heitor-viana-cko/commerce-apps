'use strict';

var LocalServiceRegistry = require('dw/svc/LocalServiceRegistry');
var Logger = require('dw/system/Logger');

var config = require('*/cartridge/scripts/checkoutcom/config');

/**
 * HTTP client for the Checkout.com APIs. Service ids, configured in
 * impex/install/services.xml:
 *
 *   cko.flow.sessions.{mode}.service  POST /payment-sessions
 *   cko.flow.submit.{mode}.service    POST /payment-sessions/{id}/submit
 *   cko.flow.payments.{mode}.service  GET  /payments/{id}, and GET /payments?reference=
 *   cko.flow.captures.{mode}.service  POST /payments/{id}/captures
 *   cko.flow.voids.{mode}.service     POST /payments/{id}/voids
 *   cko.flow.refunds.{mode}.service   POST /payments/{id}/refunds
 *
 * {mode} is sandbox or production (the Mode site preference). Credential URLs
 * carry the literal token {id}, replaced at call time; the Service Endpoint site
 * preference, when set, replaces their host.
 */

/** Response fields that must never reach the service communication log. */
var SECRET_FIELDS = /"(payment_session_secret|payment_session_token|session_data)"\s*:\s*"[^"]*"/g;

/**
 * Create the service for a logical API name in the configured mode.
 * @param {string} name The logical name: sessions, submit, payments, captures, voids or refunds
 * @returns {dw.svc.HTTPService} The service
 */
function createService(name) {
    return LocalServiceRegistry.createService('cko.flow.' + name + '.' + config.getMode() + '.service', {
        createRequest: function(svc, args) {
            svc.addHeader('Authorization', 'Bearer ' + config.getSecretKey());
            svc.addHeader('Content-Type', 'application/json;charset=UTF-8');
            svc.addHeader('User-Agent', config.PLATFORM_DATA);

            if (args && args.idempotencyKey) {
                svc.addHeader('Cko-Idempotency-Key', args.idempotencyKey);
            }

            return args && args.body ? JSON.stringify(args.body) : null;
        },
        parseResponse: function(svc, response) {
            try {
                return JSON.parse(response.text);
            } catch (e) {
                return response.text;
            }
        },
        filterLogMessage: function(message) {
            return String(message).replace(SECRET_FIELDS, '"$1":"****"');
        },
    });
}

/**
 * Call a Checkout.com API.
 * @param {string} name The logical API name
 * @param {Object} options method, id (substituted into the URL), query (replaces the
 *     /{id} segment, for list calls), body and idempotencyKey
 * @returns {{ok: boolean, object: *, errorMessage: string, rejected: boolean}} The call
 *     result. rejected is true when Checkout.com answered with a 4xx: the request was
 *     refused, nothing happened. Any other failure (timeout, 5xx, unavailable) leaves
 *     the outcome unknown.
 */
function call(name, options) {
    var service = createService(name);
    var url = service.getURL();
    var endpoint = config.getServiceEndpoint();

    if (endpoint) {
        url = url.replace(/^https?:\/\/[^/]+/, endpoint);
    }

    if (options.query) {
        url = url.replace('/{id}', '') + '?' + options.query;
    } else if (options.id) {
        url = url.replace('{id}', encodeURIComponent(options.id));
    }

    service.setURL(url);

    service.setRequestMethod(options.method || 'POST');

    var result = service.call({ body: options.body || null, idempotencyKey: options.idempotencyKey || null });

    if (config.isDebugEnabled()) {
        Logger.getLogger(config.LOG_CATEGORY).info('{0} {1} -> {2}', options.method || 'POST', url, result.isOk() ? 'OK' : 'HTTP ' + result.getError());
    }

    if (result.isOk()) {
        return { ok: true, object: result.getObject(), errorMessage: null, rejected: false };
    }

    var httpStatus = Number(result.getError());

    return {
        ok: false,
        object: null,
        errorMessage: result.getErrorMessage() || ('HTTP ' + result.getError()),
        rejected: result.getStatus() === 'ERROR' && httpStatus >= 400 && httpStatus < 500,
    };
}

module.exports = {
    /**
     * @param {Object} payload The payment session request
     * @returns {Object} The call result; object is the payment session
     */
    createPaymentSession: function(payload) {
        return call('sessions', { method: 'POST', body: payload });
    },

    /**
     * Submit the payment collected by Flow (used from its handleSubmit callback).
     * @param {string} sessionId The payment session id (ps_...)
     * @param {Object} payload session_data plus the amount, reference and items to charge
     * @returns {Object} The call result; object is returned to Flow unmodified
     */
    submitPaymentSession: function(sessionId, payload) {
        return call('submit', { method: 'POST', id: sessionId, body: payload });
    },

    /**
     * @param {string} paymentId The payment id (pay_...)
     * @returns {Object} The call result; object is the payment
     */
    getPayment: function(paymentId) {
        return call('payments', { method: 'GET', id: paymentId });
    },

    /**
     * Capture a payment (the capturePayment utility hook).
     * @param {string} paymentId The payment id
     * @param {number} amount The amount in Checkout.com minor units
     * @param {string} reference A reference for the capture
     * @returns {Object} The call result
     */
    capturePayment: function(paymentId, amount, reference) {
        return call('captures', { method: 'POST', id: paymentId, body: { amount: amount, reference: reference }, idempotencyKey: 'sfcc_capture_' + paymentId });
    },

    /**
     * @param {string} paymentId The payment id
     * @param {string} reference A reference for the void
     * @returns {Object} The call result
     */
    voidPayment: function(paymentId, reference) {
        return call('voids', { method: 'POST', id: paymentId, body: { reference: reference }, idempotencyKey: 'sfcc_void_' + paymentId });
    },

    /**
     * @param {string} paymentId The payment id
     * @param {string} reference A reference for the refund
     * @returns {Object} The call result
     */
    refundPayment: function(paymentId, reference) {
        // One automatic refund per payment, even when two requests reverse it at once
        return call('refunds', { method: 'POST', id: paymentId, body: { reference: reference }, idempotencyKey: 'sfcc_refund_' + paymentId });
    },

    /**
     * The payments made with a reference (an order number), newest first.
     * @param {string} reference The payment reference
     * @returns {Object} The call result; object.data is the list of payments
     */
    listPayments: function(reference) {
        return call('payments', { method: 'GET', query: 'reference=' + encodeURIComponent(reference) + '&limit=10' });
    },
};
