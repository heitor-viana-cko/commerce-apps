'use strict';

/**
 * sfcc.app.payment.* extension points (Payment Commerce Apps, Beta). Each
 * export is named after the last segment of its extension point; the
 * implementations are in scripts/checkoutcom/payments.js.
 *
 * An unexpected exception is logged with the hook name and returned as
 * Status.ERROR, which the platform treats as it would the exception: the basket
 * operation is rolled back, or the order is failed and its basket reopened.
 */

var Logger = require('dw/system/Logger');
var Status = require('dw/system/Status');

var config = require('*/cartridge/scripts/checkoutcom/config');
var payments = require('*/cartridge/scripts/checkoutcom/payments');

/**
 * Run a hook implementation, turning an exception into Status.ERROR.
 * @param {string} name The hook name
 * @param {Arguments} args The hook arguments
 * @returns {dw.system.Status} The hook's status
 */
function run(name, args) {
    try {
        return payments[name].apply(payments, args);
    } catch (e) {
        Logger.getLogger(config.LOG_CATEGORY).error('sfcc.app.payment.{0} failed: {1}\n{2}', name, e.message, e.stack);

        return new Status(Status.ERROR, 'UNEXPECTED_ERROR', e.message);
    }
}

/** @returns {string[]} The payment methods this app claims; none if the claim cannot be read */
exports.getClaimedPaymentMethods = function() {
    try {
        return payments.getClaimedPaymentMethods();
    } catch (e) {
        Logger.getLogger(config.LOG_CATEGORY).error('sfcc.app.payment.getClaimedPaymentMethods failed: {0}', e.message);

        return [];
    }
};

exports.afterCreateBasketPaymentInstrument = function() {
    return run('afterCreateBasketPaymentInstrument', arguments);
};

exports.afterUpdateBasketPaymentInstrument = function() {
    return run('afterUpdateBasketPaymentInstrument', arguments);
};

exports.afterUpdateOrderPaymentInstrument = function() {
    return run('afterUpdateOrderPaymentInstrument', arguments);
};

exports.onAttemptOrderTransition = function() {
    return run('onAttemptOrderTransition', arguments);
};

exports.reversePayment = function() {
    return run('reversePayment', arguments);
};

exports.authorizePayment = function() {
    return run('authorizePayment', arguments);
};

exports.cancelAuthorization = function() {
    return run('cancelAuthorization', arguments);
};

exports.capturePayment = function() {
    return run('capturePayment', arguments);
};

exports.refundCapture = function() {
    return run('refundCapture', arguments);
};
