/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Which Checkout.com public key Flow uses. The Payment Commerce Apps guide puts
 * publishable keys in the extension's environment config, so the storefront's
 * `PUBLIC__app__extension__checkoutcom__publicKey` wins when it is set. The
 * Business Manager *Public Key* (returned with the payment session) is the
 * fallback, for storefronts that don't set the variable.
 *
 * A key must match the instance's Mode: a sandbox key (`pk_sbox_…`) only with
 * the sandbox environment, a production key (`pk_…`) only with production.
 * A key that doesn't match is ignored, so a forgotten variable after switching
 * Mode falls back to Business Manager instead of breaking the payment step.
 */

export type FlowEnvironment = 'sandbox' | 'production';

export type PublicKeySource = 'environment' | 'business-manager';

/** @returns True when the key is a Checkout.com public key for the environment */
export function matchesEnvironment(key: string, environment: FlowEnvironment): boolean {
    if (!/^pk_[A-Za-z0-9_-]+$/.test(key)) {
        return false;
    }

    return key.startsWith('pk_sbox_') === (environment === 'sandbox');
}

/**
 * @param environmentKey The extension config value (environment variable), if any
 * @param instanceKey The Business Manager value returned with the session, if any
 * @param environment The instance's Mode
 * @returns The key Flow uses and where it came from, or null when neither is usable
 */
export function resolvePublicKey(
    environmentKey: string | undefined | null,
    instanceKey: string | undefined | null,
    environment: FlowEnvironment
): { publicKey: string; source: PublicKeySource } | null {
    const fromEnvironment = environmentKey?.trim();

    if (fromEnvironment && matchesEnvironment(fromEnvironment, environment)) {
        return { publicKey: fromEnvironment, source: 'environment' };
    }

    const fromInstance = instanceKey?.trim();

    if (fromInstance && matchesEnvironment(fromInstance, environment)) {
        return { publicKey: fromInstance, source: 'business-manager' };
    }

    return null;
}
