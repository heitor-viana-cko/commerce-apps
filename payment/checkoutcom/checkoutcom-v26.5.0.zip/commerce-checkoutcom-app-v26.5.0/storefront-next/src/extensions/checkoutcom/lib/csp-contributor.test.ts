/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */
import { describe, it, expect } from 'vitest';
import { validateContributors } from '@salesforce/storefront-next-runtime/security';
import { createCheckoutcomCspContributor, getCheckoutcomCspContribution } from './csp-contributor';

describe('Checkout.com CSP contributor', () => {
    it('contributes the exact Flow hosts, production and sandbox', () => {
        const contribution = getCheckoutcomCspContribution();

        expect(contribution['script-src']).toEqual(
            expect.arrayContaining([
                'https://checkout-web-components.checkout.com',
                'https://checkout-web-components.sandbox.checkout.com',
                'https://risk.checkout.com',
                'https://risk.sandbox.checkout.com',
            ])
        );
        expect(contribution['connect-src']).toContain('https://devices.api.checkout.com');
        expect(contribution['connect-src']).toContain('https://checkout-web-components-events.sandbox.checkout.com');
        expect(contribution['frame-src']).toContain('https://authentication-devices.sandbox.checkout.com');
        expect(contribution['img-src']).toContain('https://risk.checkout.com');
    });

    it('contributes the wallet hosts: Apple Pay, Google Pay and PayPal', () => {
        const contribution = getCheckoutcomCspContribution();

        expect(contribution['connect-src']).toEqual(
            expect.arrayContaining([
                'https://apme-api.checkout.com',
                'https://apme-api.sandbox.checkout.com',
                'https://apple-pay-gateway.apple.com',
                'https://pay.google.com',
            ])
        );
        expect(contribution['script-src']).toEqual(
            expect.arrayContaining([
                'https://pay.google.com',
                'https://www.paypal.com',
                'https://www.sandbox.paypal.com',
                'https://www.paypalobjects.com',
            ])
        );
        expect(contribution['frame-src']).toEqual(
            expect.arrayContaining([
                'https://pay.google.com',
                'https://www.paypal.com',
                'https://www.sandbox.paypal.com',
            ])
        );
    });

    it('lists each host once per directive, and never a wildcard', () => {
        Object.values(getCheckoutcomCspContribution()).forEach((list) => {
            expect(new Set(list).size).toBe(list?.length);
        });
        expect(JSON.stringify(getCheckoutcomCspContribution())).not.toContain('*');
    });

    it('passes the runtime contributor validation (https only, no wildcards)', () => {
        expect(() => validateContributors([createCheckoutcomCspContributor()])).not.toThrow();
    });
});
