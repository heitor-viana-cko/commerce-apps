/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Verify a completed Flow payment and place its order (idempotent).
 *
 * POST { paymentId, orderNo? } -> 200 CompletionResult (complete | failed | unverified) | 4xx
 */
import type { ActionFunctionArgs } from 'react-router';
import { getBasket } from '@/middlewares/basket.server';
import { getLogger } from '@/lib/logger.server';
import { completePayment, createOrder, type CompletionResult } from '../lib/checkoutcom.server';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const logger = getLogger(context);
    const { paymentId, orderNo } = ((await request.json().catch(() => ({}))) ?? {}) as {
        paymentId?: string;
        orderNo?: string;
    };

    if (!paymentId) {
        return Response.json({ status: 'failed', errorMessage: 'paymentId is required' }, { status: 400 });
    }

    // The order this request created, so a failure can still point the shopper to it
    let createdOrderNo: string | undefined;

    try {
        if (orderNo) {
            return Response.json(await completePayment(context, { paymentId, orderNo }));
        }

        // A payment completed without an order (a wallet that paid without
        // handleSubmit). It may already have one: a retried callback after a lost
        // response. The instance finds it through the payment's binding.
        const existing = await completePayment(context, { paymentId });

        if (existing.status !== 'no_order') {
            return Response.json(existing);
        }

        // Otherwise create the order from the basket it was made for; the instance
        // binds the payment to it before anything else can fail
        const basketId = (await getBasket(context, { ensureBasket: 'read' })).current?.basketId;

        if (!basketId) {
            return Response.json({ status: 'failed', errorMessage: 'No basket for this payment' }, { status: 409 });
        }

        createdOrderNo = (await createOrder(context, basketId)).orderNo as string;

        return Response.json(await completePayment(context, { paymentId, orderNo: createdOrderNo, basketId }));
    } catch (error) {
        logger.error('[checkoutcom] payment completion failed', {
            paymentId,
            orderNo,
            createdOrderNo,
            error: String(error),
        });

        // Not knowing is not a decline: the order stays open for a retry or a webhook
        const result: CompletionResult = {
            status: 'unverified',
            orderNo: orderNo ?? createdOrderNo ?? null,
            errorMessage: 'The payment could not be confirmed yet',
        };

        return Response.json(result);
    }
}
