/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * The hand-off between the payment step wrapper and the Flow component.
 *
 * The template's Place Order callback (`onPlaceOrder`) is registered by the
 * wrapper at `sfcc.checkout.payment`, which stays mounted with the payment step.
 * Flow itself renders at `sfcc.checkout.payment.paymentMethods`, inside the
 * step's edit view, and unmounts when the shopper collapses the step. So Flow
 * only offers its place-order function here while it is mounted.
 */

export type PlaceOrderHandler = () => Promise<string | null>;

let current: PlaceOrderHandler | null = null;

/**
 * Offer the place-order function of the mounted Flow component.
 * @returns A function that withdraws it (call on unmount)
 */
export function registerPlaceOrderHandler(handler: PlaceOrderHandler): () => void {
    current = handler;

    return () => {
        if (current === handler) {
            current = null;
        }
    };
}

/** @returns The mounted Flow component's place-order function, or null when Flow is not shown */
export function getPlaceOrderHandler(): PlaceOrderHandler | null {
    return current;
}
