/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Checkout.com extension configuration, available at
 * `config.app.extension.checkoutcom`. Override per environment with
 * `PUBLIC__app__extension__checkoutcom__<setting>`.
 *
 * The keys and the sandbox/production environment are not here: they come from
 * the instance (Business Manager site preferences) with every payment session,
 * so they are configured in one place. Nothing secret ever belongs here.
 */
export default {
    /**
     * Your Checkout.com account's API prefix: the `<prefix>` of
     * `https://<prefix>.api.checkout.com` shown on the Checkout.com Dashboard
     * (Developers > Overview). Flow frames that account-specific host for 3D
     * Secure device checks, so the Content Security Policy must allow it
     * (lib/csp-contributor.ts). Set it with
     * `PUBLIC__app__extension__checkoutcom__accountPrefix`; it is not a secret.
     */
    accountPrefix: '',
};
