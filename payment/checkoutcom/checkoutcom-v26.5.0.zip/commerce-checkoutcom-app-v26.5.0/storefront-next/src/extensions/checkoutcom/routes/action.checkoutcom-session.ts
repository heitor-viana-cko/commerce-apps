/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Create the Checkout.com payment session for the shopper's basket, after
 * making sure the basket carries a CHECKOUTCOM_FLOW payment instrument.
 *
 * POST { locale? } -> 200 { paymentSession, publicKey, environment } | 4xx/5xx { error }
 */
import type { ActionFunctionArgs } from 'react-router';
import { getConfig } from '@salesforce/storefront-next-runtime/config';
import { getBasket, updateBasketResource } from '@/middlewares/basket.server';
import { getLogger } from '@/lib/logger.server';
import { createPaymentSession, ensurePaymentInstrument, getReturnUrls } from '../lib/checkoutcom.server';
import { resolvePublicKey } from '../lib/public-key';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const logger = getLogger(context);
    const { locale } = ((await request.json().catch(() => ({}))) ?? {}) as { locale?: string };

    try {
        const basket = (await getBasket(context)).current;

        if (!basket?.basketId) {
            return Response.json({ error: 'No basket' }, { status: 409 });
        }

        const updated = await ensurePaymentInstrument(context, basket);

        updateBasketResource(context, updated);

        const session = await createPaymentSession(context, {
            basket: updated,
            locale,
            ...getReturnUrls(request, context),
        });
        // PUBLIC__app__extension__checkoutcom__publicKey first, the Business Manager key otherwise
        const environmentKey = (getConfig(context).extension as { checkoutcom?: { publicKey?: string } } | undefined)
            ?.checkoutcom?.publicKey;
        const key = resolvePublicKey(environmentKey, session.publicKey, session.environment);

        if (!key) {
            logger.error('[checkoutcom] no Checkout.com public key for this Mode', {
                environment: session.environment,
            });

            return Response.json({ error: 'No Checkout.com public key is configured' }, { status: 502 });
        }

        if (environmentKey && key.source !== 'environment') {
            logger.warn(
                '[checkoutcom] the public key environment variable does not match the instance Mode; using Business Manager',
                {
                    environment: session.environment,
                }
            );
        }

        return Response.json({ ...session, publicKey: key.publicKey });
    } catch (error) {
        logger.error('[checkoutcom] payment session creation failed', { error: String(error) });

        return Response.json({ error: 'Payment session creation failed' }, { status: 502 });
    }
}
