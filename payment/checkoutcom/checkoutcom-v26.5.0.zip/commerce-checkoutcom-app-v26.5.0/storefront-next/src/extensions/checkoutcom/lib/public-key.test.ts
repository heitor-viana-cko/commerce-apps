/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */
import { describe, it, expect } from 'vitest';
import { matchesEnvironment, resolvePublicKey } from './public-key';

describe('Checkout.com public key: environment config first, Business Manager as fallback', () => {
    it('uses the environment variable when it is set and matches the Mode', () => {
        expect(resolvePublicKey('pk_sbox_env', 'pk_sbox_bm', 'sandbox')).toEqual({
            publicKey: 'pk_sbox_env',
            source: 'environment',
        });
        expect(resolvePublicKey('pk_env', 'pk_bm', 'production')).toEqual({
            publicKey: 'pk_env',
            source: 'environment',
        });
    });

    it('falls back to Business Manager when the variable is empty or missing', () => {
        expect(resolvePublicKey('', 'pk_sbox_bm', 'sandbox')).toEqual({
            publicKey: 'pk_sbox_bm',
            source: 'business-manager',
        });
        expect(resolvePublicKey(undefined, 'pk_sbox_bm', 'sandbox')?.source).toBe('business-manager');
    });

    it('ignores a key for the other Mode, so switching Mode never breaks the payment step', () => {
        // A sandbox key left in the environment after switching the instance to production
        expect(resolvePublicKey('pk_sbox_env', 'pk_bm', 'production')).toEqual({
            publicKey: 'pk_bm',
            source: 'business-manager',
        });
        expect(resolvePublicKey('pk_env', 'pk_sbox_bm', 'sandbox')).toEqual({
            publicKey: 'pk_sbox_bm',
            source: 'business-manager',
        });
    });

    it('returns null when neither key is usable, and never accepts a secret key', () => {
        expect(resolvePublicKey('', '', 'sandbox')).toBeNull();
        expect(resolvePublicKey('sk_sbox_secret', null, 'sandbox')).toBeNull();
        expect(matchesEnvironment('sk_sbox_secret', 'sandbox')).toBe(false);
        expect(resolvePublicKey('  pk_sbox_env  ', null, 'sandbox')?.publicKey).toBe('pk_sbox_env');
    });
});
