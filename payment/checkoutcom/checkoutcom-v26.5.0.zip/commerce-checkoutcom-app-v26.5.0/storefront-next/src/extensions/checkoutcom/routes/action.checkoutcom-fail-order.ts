/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Give up on an order's payment: the instance fails the order and reopens the
 * basket so the shopper can pay again, unless Checkout.com has a payment for it,
 * which completes the order instead (see releaseOrder).
 *
 * POST { orderNo } -> 200 CompletionResult (complete | failed | unverified) | 400
 */
import type { ActionFunctionArgs } from 'react-router';
import { getLogger } from '@/lib/logger.server';
import { releaseOrder, type CompletionResult } from '../lib/checkoutcom.server';

export async function action({ request, context }: ActionFunctionArgs): Promise<Response> {
    if (request.method !== 'POST') {
        return new Response(null, { status: 405 });
    }

    const { orderNo } = ((await request.json().catch(() => ({}))) ?? {}) as { orderNo?: string };

    if (!orderNo) {
        return Response.json({ error: 'orderNo is required' }, { status: 400 });
    }

    let result: CompletionResult;

    try {
        result = await releaseOrder(context, orderNo);
    } catch (error) {
        // Not knowing is not a reason to reopen the basket: money may have moved
        result = { status: 'unverified', orderNo, errorMessage: String(error) };
    }

    getLogger(context).info('[checkoutcom] release order', { orderNo, status: result.status });

    return Response.json(result);
}
