/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Content Security Policy contributor for Checkout.com Flow: the exact hosts
 * Flow and its wallets (Apple Pay, Google Pay, PayPal) load scripts from, call,
 * frame and load images from (Checkout.com's documented list). Register it in src/middlewares/security-headers.server.ts:
 *
 *     // @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
 *     import { createCheckoutcomCspContributor } from '@/extensions/checkoutcom/lib/csp-contributor';
 *     ...
 *     const contributors = [
 *         ...
 *         // @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
 *         createCheckoutcomCspContributor(),
 *     ];
 *
 * Production and sandbox hosts are both contributed: the policy is built when
 * the storefront starts, while the Checkout.com mode is a Business Manager
 * preference that can change at any time.
 */
import type { CspContribution, CspContributor } from '@salesforce/storefront-next-runtime/security';

type Directive = 'script-src' | 'connect-src' | 'frame-src' | 'img-src';

/**
 * The hosts per directive, for one Checkout.com environment. Flow itself, then
 * the wallets it renders: Apple Pay (merchant validation), Google Pay and PayPal
 * (scripts, frames and button images).
 */
function hosts(env: 'production' | 'sandbox'): Record<Directive, string[]> {
    const cko = env === 'production' ? 'checkout.com' : 'sandbox.checkout.com';
    const paypal = env === 'production' ? 'www.paypal.com' : 'www.sandbox.paypal.com';

    return {
        'script-src': [
            `checkout-web-components.${cko}`,
            `risk.${cko}`,
            'pay.google.com',
            paypal,
            'www.paypalobjects.com',
        ],
        'connect-src': [
            `api.${cko}`,
            `devices.api.${cko}`,
            `checkout-web-components-events.${cko}`,
            `risk.${cko}`,
            `apme-api.${cko}`,
            'apple-pay-gateway.apple.com',
            'pay.google.com',
            paypal,
        ],
        'frame-src': [`authentication-devices.${cko}`, 'pay.google.com', paypal],
        'img-src': [`risk.${cko}`, paypal, 'www.paypalobjects.com'],
    };
}

/** @returns The hosts per directive, production and sandbox, without duplicates */
export function getCheckoutcomCspContribution(): CspContribution {
    const production = hosts('production');
    const sandbox = hosts('sandbox');
    const contribution: CspContribution = {};

    (Object.keys(production) as Directive[]).forEach((directive) => {
        contribution[directive] = [...new Set([...production[directive], ...sandbox[directive]])].map(
            (host) => `https://${host}`
        );
    });

    return contribution;
}

export function createCheckoutcomCspContributor(): CspContributor {
    return {
        id: 'checkoutcom-flow',
        isActive: () => true,
        contribute: getCheckoutcomCspContribution,
    };
}
