/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Content Security Policy contributor for Checkout.com Flow: the exact hosts
 * Flow and its wallets (Apple Pay, Google Pay, PayPal) load scripts from, call,
 * frame and load images from (Checkout.com's documented list, checked against
 * the hosts Flow's script uses). Register it in
 * src/middlewares/security-headers.server.ts:
 *
 *     // @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
 *     import { createCheckoutcomCspContributor } from '@/extensions/checkoutcom/lib/csp-contributor';
 *     ...
 *     const contributors = [
 *         ...
 *         // @sfdc-extension-line SFDC_EXT_CHECKOUTCOM
 *         createCheckoutcomCspContributor(config.extension?.checkoutcom),
 *     ];
 *
 * Production and sandbox hosts are both contributed: the policy is built when
 * the storefront starts, while the Checkout.com mode is a Business Manager
 * preference that can change at any time.
 */
import type { CspContribution, CspContributor } from '@salesforce/storefront-next-runtime/security';

type Directive = 'script-src' | 'connect-src' | 'frame-src' | 'img-src';

/** The extension config the contributor reads (config.ts). */
export interface CheckoutcomCspOptions {
    /** The account's API prefix, for https://<prefix>.api.checkout.com. */
    accountPrefix?: string;
}

/** A Checkout.com account prefix: lower-case letters and digits only. */
const PREFIX = /^[a-z0-9]{1,32}$/;

/**
 * The hosts per directive, for one Checkout.com environment. Flow itself, then
 * the wallets it renders: Apple Pay (merchant validation), Google Pay and PayPal
 * (scripts, frames and button images).
 */
function hosts(env: 'production' | 'sandbox', accountPrefix?: string): Record<Directive, string[]> {
    const cko = env === 'production' ? 'checkout.com' : 'sandbox.checkout.com';
    const paypal = env === 'production' ? 'www.paypal.com' : 'www.sandbox.paypal.com';
    // The account-specific API host, framed for 3D Secure device checks
    const account = accountPrefix && PREFIX.test(accountPrefix) ? [`${accountPrefix}.api.${cko}`] : [];

    return {
        'script-src': [
            `checkout-web-components.${cko}`,
            `risk.${cko}`,
            'pay.google.com',
            paypal,
            'www.paypalobjects.com',
        ],
        'connect-src': [
            // Flow's own host: its source map, fetched by the browser developer tools
            `checkout-web-components.${cko}`,
            `api.${cko}`,
            ...account,
            `devices.api.${cko}`,
            `checkout-web-components-events.${cko}`,
            `risk.${cko}`,
            `card-acquisition-gateway.${cko}`,
            `apme-api.${cko}`,
            'apple-pay-gateway.apple.com',
            'pay.google.com',
            'google.com',
            paypal,
        ],
        // Flow's card fields and Remember Me device frame are pages on its own
        // host; risk is the fraud check's device frame
        'frame-src': [
            `checkout-web-components.${cko}`,
            `authentication-devices.${cko}`,
            `risk.${cko}`,
            ...account,
            'pay.google.com',
            paypal,
        ],
        // cdnjs serves the country flags of Flow's phone and address fields
        'img-src': [`risk.${cko}`, 'cdnjs.cloudflare.com', paypal, 'www.paypalobjects.com'],
    };
}

/** @returns The hosts per directive, production and sandbox, without duplicates */
export function getCheckoutcomCspContribution(options: CheckoutcomCspOptions = {}): CspContribution {
    const production = hosts('production', options.accountPrefix);
    const sandbox = hosts('sandbox', options.accountPrefix);
    const contribution: CspContribution = {};

    (Object.keys(production) as Directive[]).forEach((directive) => {
        contribution[directive] = [...new Set([...production[directive], ...sandbox[directive]])].map(
            (host) => `https://${host}`
        );
    });

    return contribution;
}

/** @param options The extension config: `config.extension?.checkoutcom` */
export function createCheckoutcomCspContributor(options: CheckoutcomCspOptions = {}): CspContributor {
    return {
        id: 'checkoutcom-flow',
        isActive: () => true,
        contribute: () => getCheckoutcomCspContribution(options),
    };
}
