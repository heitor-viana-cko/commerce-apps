/** @sfdc-extension-file SFDC_EXT_CHECKOUTCOM */

/**
 * Checkout.com's amount formats, which differ from ISO 4217 decimals for some
 * currencies (CLP is sent times 100). Same table as the cartridge's payload.js:
 * https://www.checkout.com/docs/payments/accept-payments/format-the-amount-value
 */
const FULL_VALUE_CURRENCIES = [
    'BIF',
    'DJF',
    'GNF',
    'ISK',
    'JPY',
    'KMF',
    'KRW',
    'PYG',
    'RWF',
    'UGX',
    'VUV',
    'VND',
    'XAF',
    'XOF',
    'XPF',
];
const THOUSANDTHS_CURRENCIES = ['BHD', 'IQD', 'JOD', 'KWD', 'LYD', 'OMR', 'TND'];

/** Convert an amount to Checkout.com minor units. */
export function toMinorUnits(amount: number, currency: string): number {
    const code = currency.toUpperCase();

    if (FULL_VALUE_CURRENCIES.includes(code)) {
        return Math.round(amount);
    }

    if (THOUSANDTHS_CURRENCIES.includes(code)) {
        return Math.round(amount * 100) * 10;
    }

    if (code === 'CLP') {
        return Math.round(amount) * 100;
    }

    return Math.round(amount * 100);
}
